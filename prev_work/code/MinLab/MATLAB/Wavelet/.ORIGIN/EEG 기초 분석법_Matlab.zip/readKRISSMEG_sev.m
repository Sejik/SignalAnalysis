
function [data, ch_index] = readKRISSMEG_sev(filepath)

% Reads KRISSMEG binary file
% filepath: path of KRISSMEG binary file, extention should be included. 
% When filepath is empty, file selecting user interface will pop up.
%
% coded by Sanghyun Lim @KRISS, santagravity@gmail.com
% lastest update: 2012.01.06

    % get filepath
    if nargin == 0
        filepath = uigetfile('*.bin');
    end
    fid = fopen(filepath);
    num_info = fread(fid,1,'double','ieee-be');
    info = fread(fid,num_info,'double','ieee-be');
    display(['OPENING: ' filepath]);
    
    %read info
    scan_rate = info(1);
    temp = info(2);
    temp_num_ch = info(3);
    info = info(4:num_info);
    num_ch = numel(info)/4;
    if info(1) < 1
        scans = scan_rate;
        pretrigger = 0;
    else
        pretrigger = info(1);
        scans = temp;
        info(1) = [];
    end
    info = reshape(info,numel(info)/num_ch,num_ch);
    offsets = info(1,:);
    gains = info(2:numel(info)/num_ch,:)';
    scale = gains(1,:);
    ch_index = fread(fid,num_ch,'int16','ieee-be') +1;
   
    %read whole data
    data = [];
    while ~feof(fid) 
        temp = fread(fid,[scans, num_ch],'int16','ieee-be');
        temp = temp';
        data = [data temp];
    end
    
    % scale data
    for i = 1:num_ch
        temp = ones(1,size(data,2))*offsets(i);
        for j = 1:size(gains,2)
            temp = temp + gains(i,j)*(data(i,:).^j);
        end
        data(i,:) = temp;
    end
    data = data*10^9*11.395622912019947;
%     data = data*10^9*11.4;
    
    fid = fclose(fid);
end