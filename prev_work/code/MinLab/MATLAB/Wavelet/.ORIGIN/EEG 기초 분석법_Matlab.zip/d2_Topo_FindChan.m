%% Topo_FindChan.m %%
% �ΰ����� �ڵ� �Դϴ�.
% Analyzer�� �̿����� �ʰ� �ٷ� �ִ� Peak���� ���� ������ �׷������� �Ͻ� �� �̿��Ͻø� �˴ϴ�.
% �� �ڵ带 �����Ͽ� ������ �׸��� ����� �����غ��ŵ� �˴ϴ�. �м��� ���������� ���̴� �ڵ�� �ƴմϴ�.


clear;
close all
%% Header

channame={'Fp1','Fp2','F7','F3','Fz','F4','F8','FC5','FC1','FC2','FC6','T7','C3','Cz','C4','T8','EOG','CP5','CP1','CP2','CP6','NULL','P7','P3','Pz','P4','P8','PO9','O1','Oz','O2','PO10'};
dataname={'ExpectedTarget', 'UnexpectedNontarget'};
trialname={'Conv', 'Div'};
subname={'su0001', 'su0002', 'su0003' };

freqname={'alpha', 'beta', 'theta'};

alpha=8:1/2:13;
beta=13:1/2:30;
theta=4:1/2:8;

chanlist=[1:16, 18:21, 23:32];

ananame={'TFe_bl','TFi', 'TFi_bl'};

timelist=cell(3,1);
timelist{1,1}=[251:501];
timelist{2,1}=[51:201];
timelist{3,1}=[51:201];


for ananumb=1:length(ananame)
    
    timewindow=timelist{ananumb,1};
    
    for datanumb=1:length(dataname)
        for trialnumb=1:length(trialname)
            
            for freqnumb=1:length(freqname)
                eval(['freqband=' char(freqname{freqnumb}) ';']);
                freqindex=2*freqband-1;
                
                eval(['DataBuf = importdata(''EXP_New_FrequencyData_GrandAverage_' char(ananame{ananumb}) '_' char(freqname{freqnumb}) '_' char(trialname{trialnumb}) '_' char(dataname{datanumb}) '.dat'');']);
                
                Potential_Buf=DataBuf(timewindow,:);
                [buf1 buf2]=max(Potential_Buf);
                [bufbuf1 bufbuf2]=max(buf1);
                
                MaxValue=bufbuf1;
                MaxTpoint= buf2(bufbuf2) + timewindow(1) -1 ;
                
                potential_topo=DataBuf(MaxTpoint, :);
                potential_topo(:,[17 22])=NaN;
                
                MaxMaxChan= bufbuf2;
                
                % TopoPlot
                figure;
                [h,z]=topoplot(double(potential_topo),'EEG_32chan.ced', 'style', 'map', 'electrodes', 'numbers');
                eval(['title(sprintf(''' char(ananame{ananumb}) ' ' char(trialname{trialnumb}) ' ' char(dataname{datanumb}) ' Frequency: %d ~ %d Hz\n Max Ch: %d (%d ms)'', freqband(1), freqband(end), MaxMaxChan, MaxTpoint*2 - 501));']);
                
                % caxis([-MaxMax, MaxMax]);
                colorbar;
                
                eval(['fname=''topo_Exp_New_GrandAveraged_' char(ananame{ananumb}) '_' char(freqname{freqnumb}) '_' char(trialname{trialnumb}) '_' char(dataname{datanumb})  '.jpg'';']);
                print('-djpeg', fname);
                close all
            end
        end
    end
end
                        